# SWE-bench Instance: pallets__flask-4045

**Repository:** pallets/flask
**Base Commit:** d8c37f43724cd9fb0870f77877b7c4c7e38a19e0

## Problem Statement

Raise error when blueprint name contains a dot
This is required since every dot is now significant since blueprints can be nested. An error was already added for endpoint names in 1.0, but should have been added for this as well.


## Repository Contents

This repository contains the actual source code from the original repository at commit `d8c37f43724cd9fb0870f77877b7c4c7e38a19e0`. The code is ready for development and testing.

## Quick Start

1. **Setup environment**: `./setup_repo.sh`
2. **Read the problem**: See `prompt.txt`
3. **Check test requirements**: See `check.txt`
4. **Implement your solution**
5. **Validate**: `./run_swe_tests.sh`

## Docker Environment

A Dockerfile is provided to set up the proper environment for this instance:

```bash
docker build -t swebench-instance .
docker run -it swebench-instance /bin/bash
```
