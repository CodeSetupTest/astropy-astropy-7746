#!/bin/bash
set -euxo pipefail

# SWE-bench environment setup script
source /opt/miniconda3/bin/activate
conda create -n testbed python=3.9 -y
cat <<'EOF_59812759871' > $HOME/requirements.txt
alabaster==0.7.12
asgiref==3.4.1
attrs==21.2.0
babel==2.9.1
backports.entry-points-selectable==1.1.0
blinker==1.4
certifi==2021.5.30
cffi==1.14.6
cfgv==3.3.1
charset-normalizer==2.0.6
click==8.0.1
cryptography==35.0.0
distlib==0.3.3
docutils==0.16
filelock==3.2.0
greenlet==1.1.2
identify==2.2.15
idna==3.2
imagesize==1.2.0
iniconfig==1.1.1
jinja2==3.0.1
markupsafe==2.0.1
mypy==0.910
mypy-extensions==0.4.3
nodeenv==1.6.0
packaging==21.0
pallets-sphinx-themes==2.0.1
pep517==0.11.0
pip-tools==6.3.0
platformdirs==2.4.0
pluggy==1.0.0
pre-commit==2.15.0
py==1.10.0
pycparser==2.20
pygments==2.10.0
pyparsing==2.4.7
pytest==6.2.5
python-dotenv==0.19.0
pytz==2021.1
pyyaml==5.4.1
requests==2.26.0
six==1.16.0
snowballstemmer==2.1.0
sphinx==4.2.0
sphinx-issues==1.2.0
sphinx-tabs==3.2.0
sphinxcontrib-applehelp==1.0.2
sphinxcontrib-devhelp==1.0.2
sphinxcontrib-htmlhelp==2.0.0
sphinxcontrib-jsmath==1.0.1
sphinxcontrib-log-cabinet==1.0.1
sphinxcontrib-qthelp==1.0.3
sphinxcontrib-serializinghtml==1.1.5
toml==0.10.2
tomli==1.2.1
tox==3.24.4
types-contextvars==0.1.4
types-dataclasses==0.1.7
types-setuptools==57.4.0
typing-extensions==3.10.0.2
urllib3==1.26.7
virtualenv==20.8.1
wheel==0.37.0


EOF_59812759871
conda activate testbed && python -m pip install -r $HOME/requirements.txt
rm $HOME/requirements.txt
conda activate testbed
python -m pip install setuptools==70.0.0 Werkzeug==2.3.7 Jinja2==3.0.1 itsdangerous==2.1.2 click==8.0.1 MarkupSafe==2.1.3